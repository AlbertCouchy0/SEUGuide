//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� Whole.rc ʹ��
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_WHOLE_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDD_Introduction                129
#define IDB_BITMAP1                     130
#define IDB_BITMAP2                     131
#define IDB_BITMAP3                     132
#define IDB_BITMAP4                     133
#define IDB_BITMAP5                     135
#define IDB_BITMAP6                     136
#define IDB_BITMAP7                     137
#define IDB_BITMAP8                     138
#define IDB_BITMAP9                     139
#define IDB_BITMAP10                    140
#define IDB_BITMAP11                    141
#define IDB_BITMAP12                    142
#define IDB_BITMAP13                    143
#define IDB_BITMAP14                    144
#define IDB_BITMAP15                    145
#define IDB_BITMAP16                    146
#define IDB_BITMAP17                    147
#define IDB_BITMAP18                    148
#define IDB_BITMAP19                    149
#define IDB_BITMAP20                    150
#define IDB_BITMAP21                    151
#define IDB_BITMAP22                    152
#define IDB_BITMAP23                    153
#define IDB_BITMAP24                    154
#define IDB_BITMAP25                    155
#define IDB_BITMAP26                    156
#define IDB_BITMAP27                    157
#define IDD_DIALOG2                     159
#define IDD_D2                          159
#define IDR_WAVE1                       162
#define IDD_Guidance                    163
#define IDB_BITMAP28                    168
#define IDB_BITMAP_MAIN                 169
#define IDB_BITMAP_INTRO                173
#define IDB_BITMAP_BIG                  175
#define IDB_BITMAP30                    176
#define IDB_BITMAP_SMALL                176
#define IDC_BUTTON1                     1000
#define IDC_Picture                     1001
#define IDC_OCX2                        1005
#define IDC_BUTTON2                     1006
#define IDC_ORIGINAL                    1007
#define IDC_DESTINATION                 1008
#define IDC_LEAD                        1009
#define IDC_DESTINATION2                1010
#define IDC_DESTINATION3                1011
#define IDC_DECISION                    1012
#define IDC_SMALL                       1013
#define IDC_BIG                         1014
#define IDC_chufadidian                 1015
#define IDC_mudidi                      1016
#define IDC_xiansuozaididian            1017
#define IDC_mudidi2                     1018
#define IDC_BUTTON3                     1019
#define IDC_NETADDRESS1                 1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        177
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
