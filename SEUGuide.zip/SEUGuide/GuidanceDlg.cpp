//Part1����ϵͳ
#include "stdafx.h"
#include "Whole.h"
#include "GuidanceDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
POINT Old;
CGuidanceDlg::CGuidanceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGuidanceDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGuidanceDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}
void CGuidanceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGuidanceDlg)
	DDX_Control(pDX, IDC_DESTINATION2, m_destination2);
	DDX_Control(pDX, IDC_DESTINATION3, m_destination3);
	DDX_Control(pDX, IDC_ORIGINAL, m_original);
	DDX_Control(pDX, IDC_DESTINATION, m_destination);
	//}}AFX_DATA_MAP
}
BEGIN_MESSAGE_MAP(CGuidanceDlg, CDialog)
	//{{AFX_MSG_MAP(CGuidanceDlg)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_SMALL, OnSmall)
	ON_BN_CLICKED(IDC_BIG, OnBig)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_BN_CLICKED(IDC_LEAD, OnLead)
	ON_CBN_CLOSEUP(IDC_ORIGINAL, OnCloseupOriginal)
	ON_CBN_CLOSEUP(IDC_DESTINATION, OnCloseupDestination)
	ON_CBN_CLOSEUP(IDC_DESTINATION2, OnCloseupDestination2)
	ON_LBN_SELCHANGE(IDC_DESTINATION3, OnSelchangeDestination3)
	ON_BN_CLICKED(IDC_DECISION, OnDecision)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	ON_CBN_SELCHANGE(IDC_ORIGINAL, &CGuidanceDlg::OnCbnSelchangeOriginal)
	ON_STN_CLICKED(IDC_mudidi2, &CGuidanceDlg::OnStnClickedmudidi2)
	ON_STN_CLICKED(IDC_xiansuozaididian, &CGuidanceDlg::OnStnClickedxiansuozaididian)
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//Part2������Ϣ��������
int CGuidanceDlg::DoModal() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::DoModal();
}
void CGuidanceDlg::resize()
{
	float fsp[2];
	POINT Newp; //��ȡ���ڶԻ���Ĵ�С
	CRect recta; 
	GetClientRect(&recta); //ȡ�ͻ�����С 
	Newp.x=recta.right-recta.left;
	Newp.y=recta.bottom-recta.top;
	fsp[0]=(float)Newp.x/(float)Old.x;
	fsp[1]=(float)Newp.y/(float)Old.y;
	CRect Rect;
	int woc;
	int num=0;
	CPoint OldTLPoint,TLPoint; //���Ͻ�
	CPoint OldBRPoint,BRPoint; //���½�
	HWND hwndChild=::GetWindow(m_hWnd,GW_CHILD); //�г����пؼ�
	while(hwndChild) 
	{ 
		woc=::GetDlgCtrlID(hwndChild);//ȡ��ID
		TCHAR szBuff[256];
		GetClassName(hwndChild,szBuff,sizeof(szBuff)/sizeof(TCHAR));

		GetDlgItem(woc)->GetWindowRect(Rect); 
		ScreenToClient(Rect); 
		OldTLPoint = Rect.TopLeft(); 
		TLPoint.x = long(OldTLPoint.x*fsp[0]); 
		TLPoint.y = long(OldTLPoint.y*fsp[1]); 
		OldBRPoint = Rect.BottomRight(); 
		BRPoint.x = long(OldBRPoint.x *fsp[0]); 

		if(szBuff[0]!='C' && szBuff[3]!='b') BRPoint.y = long(OldBRPoint.y *fsp[1]);//�߶Ȳ��ɶ��Ŀؼ�����:combBox),��Ҫ�ı��ֵ.
		else BRPoint.y = long(OldBRPoint.y *fsp[1]+90);
		Rect.SetRect(TLPoint,BRPoint); 
		GetDlgItem(woc)->MoveWindow(Rect,TRUE);
		hwndChild=::GetWindow(hwndChild, GW_HWNDNEXT); 
		}
	Old=Newp;
}
void CGuidanceDlg::OnPaint() 
{
	CRect rect;   
    GetClientRect(&rect); //ȡ�ͻ�����С   
	rect.top = 0;rect.top=0;
    Old.x=rect.right-rect.left;
    Old.y=rect.bottom-rect.top;
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
		CDC *pDC=GetDC();
		CBitmap BmpMem;
		CDC MemDC;

		MemDC.CreateCompatibleDC(pDC);

		if (m_size == 0)
		{
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP_SMALL);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			pPic->ShowWindow(SW_SHOW);

		
		}
		else
		{
			CStatic* pPicture = (CStatic*)GetDlgItem(IDC_Picture);
			pPicture->ShowWindow(SW_HIDE);

			BmpMem.Attach((HBITMAP)LoadImage(AfxGetInstanceHandle(),
				MAKEINTRESOURCE(IDB_BITMAP_BIG), 
				IMAGE_BITMAP,
				0, 0,
				LR_CREATEDIBSECTION));
		}
		
	

		MemDC.SelectObject(&BmpMem);
	
		pDC->BitBlt(15,15,673,551,&MemDC,0,0,SRCCOPY);

	//��ɫ����
	CBrush brs(RGB(0,0,255));
	CPen pen(PS_SOLID,1,RGB(0,0,255));
	pDC->SelectObject(pen);
	pDC->SelectObject(brs);
	//��Բ�㲿��
	pDC->Ellipse(172.0501845 - 12, 474.87638669 - 18, 182.0501845 - 12, 484.87638669 - 18);//��԰������1
	pDC->Ellipse(277.70332103 - 22, 410.21394612 - 16, 287.70332103 - 22, 420.21394612 - 16);//�����¥1
	pDC->Ellipse(332.92103321 - 22, 406.21394612 - 16, 342.92103321 - 22, 416.21394612 - 16);//����¥1
	pDC->Ellipse(423.67380074 - 18, 428.97464342 - 24, 433.67380074 - 18, 438.97464342 - 24);//��ұ�¥1
	pDC->Ellipse(552.94464945 - 22, 288.62599049 - 22, 562.94464945 - 22, 298.62599049 - 22);//������1
	pDC->Ellipse(464.98450185 - 22, 260.37400951 - 22, 474.98450185 - 22, 270.37400951 - 22);//��ѧ¥��1
	pDC->Ellipse(443.60073801 - 18, 155.82725832 - 28, 453.60073801 - 18, 165.82725832 - 28);//����¥1
	pDC->Ellipse(199.48708487 - 22, 177.43264659 - 12, 209.48708487 - 22, 187.43264659 - 12);//�Ŀ�¥1
	pDC->Ellipse(150.60664207 - 22, 340.25990491 - 16, 160.60664207 - 22, 350.25990491 - 16);//��������1
	pDC->Ellipse(202.32103321 - 16, 298.75277338 - 12, 212.32103321 - 16, 308.75277338 - 12);//Բ����1
	pDC->Ellipse(175.09520295 - 22, 314.49920761 - 10, 185.09520295 - 22, 324.49920761 - 10);//��е¥1
	pDC->Ellipse(298.07380074 - 22, 262.75277338 - 14, 308.07380074 - 22, 272.75277338 - 14);//ͼ���1
	pDC->Ellipse(393.05904059 - 22, 290.75277338 - 14, 403.05904059 - 22, 300.75277338 - 14);//ͼ��ݶ�1
	pDC->Ellipse(297.57712177 - 12, 391.59587956 - 14, 307.57712177 - 12, 401.59587956 - 14);//Բ����1
	pDC->Ellipse(296.08708487 - 22, 236.16323296 - 14, 306.08708487 - 22, 246.16323296 - 14);//��ѧ�����ѧԺ1
	pDC->Ellipse(234.00221402 - 22, 232.6703645 - 18, 244.00221402 - 22, 242.6703645 - 18);//������1
	pDC->Ellipse(293.28487085 - 22, 197.82567353 - 10, 303.28487085 - 22, 207.82567353 - 10);//ͼ��ݱ�1
	pDC->Ellipse(530.4199262 - 22, 230.92393027 - 22, 540.4199262 - 22, 240.92393027 - 22);//����1
	pDC->Ellipse(524.398524 - 28, 190.8969889 - 28, 534.4398524 - 28, 200.48969889 - 28);//��԰ʳ��1
	pDC->Ellipse(484.72693727 - 26, 77.843106181 - 18, 494.72693727 - 26, 87.843106181 - 18);//УҽԺ1
	pDC->Ellipse(318.58376384 - 16, 176.81299525 - 22, 328.58376384 - 16, 186.81299525 - 22);//����ѧԺ1
	pDC->Ellipse(620.09520295 - 22, 166.49920761 - 22, 630.09520295 - 22, 176.49920761 - 22);//��԰�ٳ�1
	pDC->Ellipse(583.09520295 - 22, 169.49920761 - 14, 593.09520295 - 22, 179.49920761 - 14);//��԰������1
	pDC->Ellipse(65.0501845 - 22, 375.87638669 - 22, 75.0501845 - 22, 385.87638669 - 22);//��԰������1
	pDC->Ellipse(534.70332103 - 16, 393.21394612 - 22, 544.70332103 - 16, 403.21394612 - 22);//÷԰����1
	pDC->Ellipse(617.67380074 - 22, 380.97464342 - 22, 627.67380074 - 22, 390.97464342 - 22);//÷԰������1
	pDC->Ellipse(561.94464945 - 22, 431.62599049 - 22, 571.94464945 - 22, 441.62599049 - 22);//÷԰������1
	pDC->Ellipse(435.98450185 - 22, 26.37400951 - 18, 445.98450185 - 22, 36.37400951 - 18);//����1
	pDC->Ellipse(54.09520295 - 40, 56.49920761 - 10, 64.09520295 - 40, 66.49920761 - 10);//����������1
	pDC->Ellipse(235.70332103 - 22, 369.21394612 - 22, 245.70332103 - 22, 379.21394612 - 22);//Բ������1
	pDC->Ellipse(372.0501845 - 20, 358.87638669 - 20, 382.0501845 - 20, 368.87638669 - 20);//Բ������1
	pDC->Ellipse(675.0501845 - 22, 280.87638669 - 22, 685.0501845 - 22, 290.87638669 - 22);//����1
	pDC->Ellipse(310.09520295 - 14, 515.49920761, 320.09520295 - 14, 525.49920761);//����1
	pDC->Ellipse(18.0501845 - 12, 302.87638669, 28.0501845 - 12, 312.87638669);//����1
	pDC->Ellipse(363.67380074 - 22, 227.97464342 - 14, 373.67380074 - 22, 237.97464342 - 14);//Բ������1
	pDC->Ellipse(368.398524 - 26, 135.8969889 - 10, 378.4398524 - 26, 145.48969889 - 10);//����ʵ����1
	pDC->Ellipse(425.0501845-22, 83.010234-22, 435.0501845-22, 93.010234-22);//������Ϣ

	//��ɫ����
	CBrush brss(RGB(255,255,0));
	CPen penn(PS_SOLID,1,RGB(255,255,0));
	pDC->SelectObject(penn);
	pDC->SelectObject(brss);
	//��Բ�㲿��
	pDC->Ellipse(151.70332103 - 20, 23.21394612, 161.70332103 - 20, 33.21394612);//36
	pDC->Ellipse(365.70332103 - 17, 27.21394612 - 12, 375.70332103 - 17, 37.21394612 - 12);//37
	pDC->Ellipse(456.70332103 - 23, 100.21394612 - 12, 466.70332103 - 23, 110.21394612 - 12);//38
	pDC->Ellipse(605.70332103 - 17, 74.21394612 - 17, 615.70332103 - 17, 84.21394612 - 17);//39
	pDC->Ellipse(603.70332103 - 17, 125.21394612 - 22, 613.70332103 - 17, 135.21394612 - 22);//40
	pDC->Ellipse(610.70332103 - 22, 287.21394612 - 22, 620.70332103 - 22, 297.21394612 - 22);//41
	pDC->Ellipse(615.70332103 - 25, 406.21394612 - 32, 625.70332103 - 25, 416.21394612 - 32);//42!
	pDC->Ellipse(562.70332103 - 25, 405.21394612 - 22, 572.70332103 - 25, 415.21394612 - 22);//43!
	pDC->Ellipse(431.70332103 - 22, 459.21394612 - 25, 441.70332103 - 22, 469.21394612 - 25);//44!
	pDC->Ellipse(327.70332103 - 22, 468.21394612 - 22, 337.70332103 - 22, 478.21394612 - 22);//45
	pDC->Ellipse(286.70332103 - 12, 474.21394612 - 25, 296.70332103 - 12, 484.21394612 - 25);//46!
	pDC->Ellipse(136.70332103 - 17, 469.21394612 - 22, 146.70332103 - 17, 479.21394612 - 22);//47
	pDC->Ellipse(49.70332103 - 12, 307.21394612 - 13, 59.70332103 - 12, 317.21394612 - 13);//48!
	pDC->Ellipse(115.09520295 - 16, 302.49920761 - 12, 125.09520295 - 16, 312.49920761 - 12);//49!
	pDC->Ellipse(113.09520295 - 22, 219.49920761 - 12, 123.09520295 - 22, 229.49920761 - 12);//50!
	pDC->Ellipse(29.09520295 - 22, 221.49920761 - 5, 39.09520295 - 22, 231.49920761 - 5);//51!
	pDC->Ellipse(119.09520295 - 22, 128.49920761 - 2, 129.09520295 - 22, 138.49920761 - 2);//52!
	pDC->Ellipse(160.09520295 - 20, 122.49920761 - 2, 170.09520295 - 20, 132.49920761 - 2);//53!
	pDC->Ellipse(495.09520295 - 17, 290.49920761 - 17, 505.09520295 - 17, 300.49920761 - 17);//54
	pDC->Ellipse(469.09520295 - 22, 143.49920761 - 17, 479.09520295 - 22, 153.49920761 - 17);//55!
	pDC->Ellipse(480.09520295 - 22, 454.49920761 - 22, 490.09520295 - 22, 464.49920761 - 22);//56
	pDC->Ellipse(342.09520295 - 17, 114.49920761 - 12, 352.09520295 - 17, 124.49920761 - 12);//57!
	pDC->Ellipse(301.09520295 - 17, 116.49920761 - 7, 311.09520295 - 17, 126.49920761 - 7);//58!
	pDC->Ellipse(272.09520295 - 22, 121.49920761 - 13, 282.09520295 - 22, 131.49920761 - 13);//59!
	pDC->Ellipse(274.09520295 - 22, 158.49920761 - 14, 284.09520295 - 22, 168.49920761 - 14);//60!
	pDC->Ellipse(219.09520295 - 2, 159.49920761 - 14, 229.09520295 - 2, 169.49920761 - 14);//61!
	pDC->Ellipse(212.09520295 - 12, 252.49920761 - 12, 222.09520295 - 12, 262.49920761 - 12);//62!
	pDC->Ellipse(112.09520295 - 12, 353.49920761 - 17, 122.09520295 - 12, 363.49920761 - 17);//63
	pDC->Ellipse(492.09520295 - 22, 374.49920761 - 22, 502.09520295 - 22, 384.49920761 - 22);//64

		BmpMem.DeleteObject();
		MemDC.DeleteDC();
		//pDC->DeleteDC();
		ReleaseDC(pDC);
		//ReleaseDC(MemDC);
		//////////////////////////////////////////////////////////////////////////

	// Do not call CDialog::OnPaint() for painting messages
}
//��ø�������
BOOL CGuidanceDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_colorOfFlash=false;
	m_size=0;
	m_lButtonDown=false;
	m_orginalPoint.x=0;
	m_orginalPoint.y=0;
	m_mapLocation.x=500;
	m_mapLocation.y=500;
	m_destinationPoint.x=0;
	m_destinationPoint.y=0;
	m_currentPoint.x=0;
	m_currentPoint.y=0;
	m_mapTempLocation.x=0;
	m_mapTempLocation.y=0;
	m_leadClicked=false;
	//��ΪԲ����������
	m_touristAttractions[0] = (177.0501845 - 12, 479.87638669 - 18);//��԰������
	m_touristAttractions[1] = (282.70332103 - 22, 415.21394612 - 16);//�����¥
	m_touristAttractions[2] = (337.92103321 - 22, 411.21394612 - 16);//����¥
	m_touristAttractions[3] = (428.67380074 - 18, 433.97464342 - 24);//��ұ�¥
	m_touristAttractions[4] = (557.94464945 - 22, 293.62599049 - 22);//������
	m_touristAttractions[5] = (469.98450185 - 22, 265.37400951 - 22);//��ѧ¥��
	m_touristAttractions[6] = (448.60073801 - 18, 160.82725832 - 28);//����¥
	m_touristAttractions[7] = (204.48708487 - 22, 182.43264659 - 12);//�Ŀ�¥
	m_touristAttractions[8] = (155.60664207 - 22, 345.25990491 - 16);//��������
	m_touristAttractions[9] = (207.32103321 - 16, 303.75277338 - 12);//Բ����
	m_touristAttractions[10] = (180.09520295 - 22, 319.49920761 - 10);//��е¥
	m_touristAttractions[11] = (303.07380074 - 22, 267.75277338 - 14);//ͼ���
	m_touristAttractions[12] = (398.05904059 - 22, 295.75277338 - 14);//ͼ��ݶ�
	m_touristAttractions[13] = (302.57712177 - 12, 396.59587956 - 14);//Բ����
	m_touristAttractions[14] = (301.08708487 - 22, 241.16323296 - 14);//��ѧ�����ѧԺ
	m_touristAttractions[15] = (239.00221402 - 22, 237.6703645 - 18);//������
	m_touristAttractions[16] = (298.28487085 - 22, 202.82567353 - 10);//ͼ��ݱ�
	m_touristAttractions[17] = (535.4199262 - 22, 235.92393027 - 22);//����
	m_touristAttractions[18] = (529.398524 - 28, 195.8969889 - 28);//��԰ʳ��
	m_touristAttractions[19] = (489.72693727 - 26, 82.843106181 - 18);//УҽԺ
	m_touristAttractions[20] = (323.58376384 - 16, 181.81299525 - 22);//����ѧԺ
	m_touristAttractions[21] = (625.09520295 - 22, 171.49920761 - 14);//��԰�ٳ�
	m_touristAttractions[22] = (588.09520295 - 22, 174.49920761 - 22);//��԰������
	m_touristAttractions[23] = (70.0501845 - 22, 380.87638669 - 22);//��԰����
	m_touristAttractions[24] = (539.70332103 - 16, 398.21394612 - 22);//÷԰����
	m_touristAttractions[25] = (622.67380074 - 22, 385.97464342 - 22);//÷԰������
	m_touristAttractions[26] = (566.94464945 - 22, 436.62599049 - 22);//÷԰������
	m_touristAttractions[27] = (440.98450185 - 22, 31.37400951 - 18);//���� 
	m_touristAttractions[28] = (59.09520295 - 40, 61.49920761 - 10);//����������
	m_touristAttractions[29] = (240.70332103 - 22, 374.21394612 - 22);//Բ������
	m_touristAttractions[30] = (377.0501845 - 20, 363.87638669 - 20);//Բ������
	m_touristAttractions[31] = (680.0501845 - 22, 285.87638669 - 22);//����
	m_touristAttractions[32] = (315.09520295, 520.49920761 - 14);//����
	m_touristAttractions[33] = (23.0501845 - 12, 307.87638669);//����
	m_touristAttractions[34] = (368.67380074 - 22, 232.97464342 - 14);//Բ������
	m_touristAttractions[35] = (372.398524 - 26, 140.8969889 - 10);//����ʵ��¥

	
	
	m_touristAttractions[36]=(156.70332103-20,28.21394612);//36
	m_touristAttractions[37]=(370.70332103-17,32.21394612-  12);//37
	m_touristAttractions[38]=(461.70332103-23,105.21394612-  12);//38
	m_touristAttractions[39]=(610.70332103-17,79.21394612-  17);//39
	m_touristAttractions[40]=(608.70332103-17,130.21394612-  22);//40
	m_touristAttractions[41]=(615.70332103-22,292.21394612-  22);//41
	m_touristAttractions[42]=(620.70332103-25,411.21394612-  32);//42
	m_touristAttractions[43]=(567.70332103-25,410.21394612-  22);//43
	m_touristAttractions[44]=(436.70332103-22,464.21394612-  25);//44
	m_touristAttractions[45]=(332.70332103-22,473.21394612-  22);//45
	m_touristAttractions[46]=(291.70332103-12,479.21394612-  25);//46
	m_touristAttractions[47]=(141.70332103-17,474.21394612-  22);//47
	m_touristAttractions[48]=(54.70332103-12,312.21394612-  13);//48
	m_touristAttractions[49]=(120.09520295-16,307.49920761-  12);//49
	m_touristAttractions[50]=(118.09520295-22,224.49920761-  12);//50
	m_touristAttractions[51]=(34.09520295-22,226.49920761-  5);//51
	m_touristAttractions[52]=(124.09520295-22,133.49920761-  2);//52
	m_touristAttractions[53]=(165.09520295-20,127.49920761-  2);//53
	m_touristAttractions[54]=(500.09520295-17,295.49920761-  17);//54
	m_touristAttractions[55]=(474.09520295-22,148.49920761-  17);//55
	m_touristAttractions[56]=(485.09520295-22,459.49920761-  22);//56
	
	m_touristAttractions[57]=(347.09520295-17,119.49920761-  12);//57
	m_touristAttractions[58]=(306.09520295-17,121.49920761-  7);//58
	m_touristAttractions[59]=(277.09520295-22,126.49920761-  13);//59
	m_touristAttractions[60]=(279.09520295-22,163.49920761-  14);//60
	m_touristAttractions[61]=(224.09520295-2,164.49920761-  14);//61
	m_touristAttractions[62]=(217.09520295-12,257.49920761-  12);//62
	m_touristAttractions[63]=(117.09520295-12,358.49920761-  17);//63
	m_touristAttractions[64]=(497.09520295-22,379.49920761-  22);//64

	
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("��԰������");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("�����¥");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("����¥");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("��ұ�¥");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("������");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("��ѧ¥��");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("����¥");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("�Ŀ�¥");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("��������");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("Բ����");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("��е¥"); 
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("ͼ���");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("ͼ��ݶ�");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("Բ����");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("��ѧ�����ѧԺ");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("������");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("ͼ��ݱ�");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("����");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("��԰ʳ��");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("УҽԺ");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("��ѧ����¥");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("��԰�ٳ�");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("��԰������");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("��԰����");
    ((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("÷԰����");
    ((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("÷԰������");
    ((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("÷԰������");
    ((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("����");
    ((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("����������");
    ((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("Բ������");
    ((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("Բ������");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("����");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("����");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("����");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("Բ������");
	((CComboBox*)GetDlgItem(IDC_ORIGINAL))->AddString("����ʵ��¥");

	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("��԰������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("�����¥");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("����¥");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("��ұ�¥");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("��ѧ¥��");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("����¥");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("�Ŀ�¥");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("��������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("Բ����");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("��е¥"); 
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("ͼ���");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("ͼ��ݶ�");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("Բ����");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("��ѧ�����ѧԺ");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("ͼ��ݱ�");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("����");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("��԰ʳ��");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("УҽԺ");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("��ѧ����¥");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("��԰�ٳ�");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("��԰������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("��԰����");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("÷԰����");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("÷԰������");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("÷԰������");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("����");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("����������");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("Բ������");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("Բ������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("����");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("����");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("����");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("Բ������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION))->AddString("����ʵ��¥");

	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("��԰������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("�����¥");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("����¥");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("��ұ�¥");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("��ѧ¥��");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("����¥");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("�Ŀ�¥");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("��������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("Բ����");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("��е¥"); 
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("ͼ���");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("ͼ��ݶ�");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("Բ����");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("��ѧ�����ѧԺ");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("ͼ��ݱ�");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("����");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("��԰ʳ��");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("УҽԺ");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("��ѧ����¥");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("��԰�ٳ�");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("��԰������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("��԰����");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("÷԰����");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("÷԰������");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("÷԰������");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("����");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("����������");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("Բ������");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("Բ������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("����");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("����");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("����");
    ((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("Բ������");
	((CComboBox*)GetDlgItem(IDC_DESTINATION2))->AddString("����ʵ��¥");
	
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("��԰������");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("�����¥");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("����¥");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("��ұ�¥");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("������");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("��ѧ¥��");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("����¥");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("�Ŀ�¥");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("��������");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("Բ����");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("��е¥"); 
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("ͼ���");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("ͼ��ݶ�");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("Բ����");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("��ѧ�����ѧԺ");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("������");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("ͼ��ݱ�");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("����");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("��԰ʳ��");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("УҽԺ");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("��ѧ����¥");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("��԰�ٳ�");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("��԰������");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("��԰����");
    ((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("÷԰����");
    ((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("÷԰������");
    ((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("÷԰������");
    ((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("����");
    ((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("����������");
    ((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("Բ������");
    ((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("Բ������");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("����");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("����");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("����");
    ((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("Բ������");
	((CListBox*)GetDlgItem(IDC_DESTINATION3))->AddString("����ʵ��¥");
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void CGuidanceDlg::OnSmall() 
{
	// TODO: Add your control notification handler code here
		
	m_size=0;

	//////////////////////////////////////////////////////////////////////////
	CDC *pDC=GetDC();
	CBitmap BmpMem;
	CDC MemDC;

	MemDC.CreateCompatibleDC(pDC);

		if (m_size == 0)
		{
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP_SMALL);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			pPic->ShowWindow(SW_SHOW);
		}
		else 
		{
			CStatic* pPicture = (CStatic*)GetDlgItem(IDC_Picture);
			pPicture->ShowWindow(SW_HIDE);

			BmpMem.Attach((HBITMAP)LoadImage(AfxGetInstanceHandle(),
				MAKEINTRESOURCE(IDB_BITMAP_BIG),
				IMAGE_BITMAP,
				0, 0,
				LR_CREATEDIBSECTION));
		}
	

		
	MemDC.SelectObject(&BmpMem);
	
	pDC->BitBlt(15,15,673,551,&MemDC,0,0,SRCCOPY);
//����
	CBrush brs(RGB(0,0,255));
	CPen pen(PS_SOLID,1,RGB(0,0,255));
	pDC->SelectObject(pen);
	pDC->SelectObject(brs);
	pDC->Ellipse(172.0501845 - 12, 474.87638669 - 18, 182.0501845 - 12, 484.87638669 - 18);//��԰������1
	pDC->Ellipse(277.70332103 - 22, 410.21394612 - 16, 287.70332103 - 22, 420.21394612 - 16);//�����¥1
	pDC->Ellipse(332.92103321 - 22, 406.21394612 - 16, 342.92103321 - 22, 416.21394612 - 16);//����¥1
	pDC->Ellipse(423.67380074 - 18, 428.97464342 - 24, 433.67380074 - 18, 438.97464342 - 24);//��ұ�¥1
	pDC->Ellipse(552.94464945 - 22, 288.62599049 - 22, 562.94464945 - 22, 298.62599049 - 22);//������1
	pDC->Ellipse(464.98450185 - 22, 260.37400951 - 22, 474.98450185 - 22, 270.37400951 - 22);//��ѧ¥��1
	pDC->Ellipse(443.60073801 - 18, 155.82725832 - 28, 453.60073801 - 18, 165.82725832 - 28);//����¥1
	pDC->Ellipse(199.48708487 - 22, 177.43264659 - 12, 209.48708487 - 22, 187.43264659 - 12);//�Ŀ�¥1
	pDC->Ellipse(150.60664207 - 22, 340.25990491 - 16, 160.60664207 - 22, 350.25990491 - 16);//��������1
	pDC->Ellipse(202.32103321 - 16, 298.75277338 - 12, 212.32103321 - 16, 308.75277338 - 12);//Բ����1
	pDC->Ellipse(175.09520295 - 22, 314.49920761 - 10, 185.09520295 - 22, 324.49920761 - 10);//��е¥1
	pDC->Ellipse(298.07380074 - 22, 262.75277338 - 14, 308.07380074 - 22, 272.75277338 - 14);//ͼ���1
	pDC->Ellipse(393.05904059 - 22, 290.75277338 - 14, 403.05904059 - 22, 300.75277338 - 14);//ͼ��ݶ�1
	pDC->Ellipse(297.57712177 - 12, 391.59587956 - 14, 307.57712177 - 12, 401.59587956 - 14);//Բ����1
	pDC->Ellipse(296.08708487 - 22, 236.16323296 - 14, 306.08708487 - 22, 246.16323296 - 14);//��ѧ�����ѧԺ1
	pDC->Ellipse(234.00221402 - 22, 232.6703645 - 18, 244.00221402 - 22, 242.6703645 - 18);//������1
	pDC->Ellipse(293.28487085 - 22, 197.82567353 - 10, 303.28487085 - 22, 207.82567353 - 10);//ͼ��ݱ�1
	pDC->Ellipse(530.4199262 - 22, 230.92393027 - 22, 540.4199262 - 22, 240.92393027 - 22);//����1
	pDC->Ellipse(524.398524 - 28, 190.8969889 - 28, 534.4398524 - 28, 200.48969889 - 28);//��԰ʳ��1
	pDC->Ellipse(484.72693727 - 26, 77.843106181 - 18, 494.72693727 - 26, 87.843106181 - 18);//УҽԺ1
	pDC->Ellipse(318.58376384 - 16, 176.81299525 - 22, 328.58376384 - 16, 186.81299525 - 22);//����ѧԺ1
	pDC->Ellipse(620.09520295 - 22, 166.49920761 - 22, 630.09520295 - 22, 176.49920761 - 22);//��԰�ٳ�1
	pDC->Ellipse(583.09520295 - 22, 169.49920761 - 14, 593.09520295 - 22, 179.49920761 - 14);//��԰������1
	pDC->Ellipse(65.0501845 - 22, 375.87638669 - 22, 75.0501845 - 22, 385.87638669 - 22);//��԰������1
	pDC->Ellipse(534.70332103 - 16, 393.21394612 - 22, 544.70332103 - 16, 403.21394612 - 22);//÷԰����1
	pDC->Ellipse(617.67380074 - 22, 380.97464342 - 22, 627.67380074 - 22, 390.97464342 - 22);//÷԰������1
	pDC->Ellipse(561.94464945 - 22, 431.62599049 - 22, 571.94464945 - 22, 441.62599049 - 22);//÷԰������1
	pDC->Ellipse(435.98450185 - 22, 26.37400951 - 18, 445.98450185 - 22, 36.37400951 - 18);//����1
	pDC->Ellipse(54.09520295 - 40, 56.49920761 - 10, 64.09520295 - 40, 66.49920761 - 10);//����������1
	pDC->Ellipse(235.70332103 - 22, 369.21394612 - 22, 245.70332103 - 22, 379.21394612 - 22);//Բ������1
	pDC->Ellipse(372.0501845 - 20, 358.87638669 - 20, 382.0501845 - 20, 368.87638669 - 20);//Բ������1
	pDC->Ellipse(675.0501845 - 22, 280.87638669 - 22, 685.0501845 - 22, 290.87638669 - 22);//����1
	pDC->Ellipse(310.09520295 - 14, 515.49920761, 320.09520295 - 14, 525.49920761);//����1
	pDC->Ellipse(18.0501845 - 12, 302.87638669, 28.0501845 - 12, 312.87638669);//����1
	pDC->Ellipse(363.67380074 - 22, 227.97464342 - 14, 373.67380074 - 22, 237.97464342 - 14);//Բ������1
	pDC->Ellipse(368.398524 - 26, 135.8969889 - 10, 378.4398524 - 26, 145.48969889 - 10);//����ʵ����1
	pDC->Ellipse(425.0501845-22, 83.010234-22, 435.0501845-22, 93.010234-22);//������Ϣ

	CBrush brss(RGB(255,255,0));
	CPen penn(PS_SOLID,1,RGB(255,255,0));
	pDC->SelectObject(penn);
	pDC->SelectObject(brss);

	pDC->Ellipse(151.70332103 - 20, 23.21394612, 161.70332103 - 20, 33.21394612);//36
	pDC->Ellipse(365.70332103 - 17, 27.21394612 - 12, 375.70332103 - 17, 37.21394612 - 12);//37
	pDC->Ellipse(456.70332103 - 23, 100.21394612 - 12, 466.70332103 - 23, 110.21394612 - 12);//38
	pDC->Ellipse(605.70332103 - 17, 74.21394612 - 17, 615.70332103 - 17, 84.21394612 - 17);//39
	pDC->Ellipse(603.70332103 - 17, 125.21394612 - 22, 613.70332103 - 17, 135.21394612 - 22);//40
	pDC->Ellipse(610.70332103 - 22, 287.21394612 - 22, 620.70332103 - 22, 297.21394612 - 22);//41
	pDC->Ellipse(615.70332103 - 25, 406.21394612 - 32, 625.70332103 - 25, 416.21394612 - 32);//42!
	pDC->Ellipse(562.70332103 - 25, 405.21394612 - 22, 572.70332103 - 25, 415.21394612 - 22);//43!
	pDC->Ellipse(431.70332103 - 22, 459.21394612 - 25, 441.70332103 - 22, 469.21394612 - 25);//44!
	pDC->Ellipse(327.70332103 - 22, 468.21394612 - 22, 337.70332103 - 22, 478.21394612 - 22);//45
	pDC->Ellipse(286.70332103 - 12, 474.21394612 - 25, 296.70332103 - 12, 484.21394612 - 25);//46!
	pDC->Ellipse(136.70332103 - 17, 469.21394612 - 22, 146.70332103 - 17, 479.21394612 - 22);//47
	pDC->Ellipse(49.70332103 - 12, 307.21394612 - 13, 59.70332103 - 12, 317.21394612 - 13);//48!
	pDC->Ellipse(115.09520295 - 16, 302.49920761 - 12, 125.09520295 - 16, 312.49920761 - 12);//49!
	pDC->Ellipse(113.09520295 - 22, 219.49920761 - 12, 123.09520295 - 22, 229.49920761 - 12);//50!
	pDC->Ellipse(29.09520295 - 22, 221.49920761 - 5, 39.09520295 - 22, 231.49920761 - 5);//51!
	pDC->Ellipse(119.09520295 - 22, 128.49920761 - 2, 129.09520295 - 22, 138.49920761 - 2);//52!
	pDC->Ellipse(160.09520295 - 20, 122.49920761 - 2, 170.09520295 - 20, 132.49920761 - 2);//53!
	pDC->Ellipse(495.09520295 - 17, 290.49920761 - 17, 505.09520295 - 17, 300.49920761 - 17);//54
	pDC->Ellipse(469.09520295 - 22, 143.49920761 - 17, 479.09520295 - 22, 153.49920761 - 17);//55!
	pDC->Ellipse(480.09520295 - 22, 454.49920761 - 22, 490.09520295 - 22, 464.49920761 - 22);//56
	pDC->Ellipse(342.09520295 - 17, 114.49920761 - 12, 352.09520295 - 17, 124.49920761 - 12);//57!
	pDC->Ellipse(301.09520295 - 17, 116.49920761 - 7, 311.09520295 - 17, 126.49920761 - 7);//58!
	pDC->Ellipse(272.09520295 - 22, 121.49920761 - 13, 282.09520295 - 22, 131.49920761 - 13);//59!
	pDC->Ellipse(274.09520295 - 22, 158.49920761 - 14, 284.09520295 - 22, 168.49920761 - 14);//60!
	pDC->Ellipse(219.09520295 - 2, 159.49920761 - 14, 229.09520295 - 2, 169.49920761 - 14);//61!
	pDC->Ellipse(212.09520295 - 12, 252.49920761 - 12, 222.09520295 - 12, 262.49920761 - 12);//62!
	pDC->Ellipse(112.09520295 - 12, 353.49920761 - 17, 122.09520295 - 12, 363.49920761 - 17);//63
	pDC->Ellipse(492.09520295 - 22, 374.49920761 - 22, 502.09520295 - 22, 384.49920761 - 22);//64

	BmpMem.DeleteObject();
	MemDC.DeleteDC();
//	pDC->DeleteDC();
	ReleaseDC(pDC);
//	ReleaseDC(MemDC);
}
void CGuidanceDlg::OnBig() 
{
	// TODO: Add your control notification handler code here
	m_size=1;

	
	//////////////////////////////////////////////////////////////////////////
	CDC *pDC=GetDC();
	CBitmap BmpMem;
	CDC MemDC;

	MemDC.CreateCompatibleDC(pDC);

	if (m_size == 0)
	{
		CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
		CBitmap bitmap;
		bitmap.LoadBitmap(IDB_BITMAP_SMALL);
		pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
		pPic->ShowWindow(SW_SHOW);
	}
	else
	{
		CStatic* pPicture = (CStatic*)GetDlgItem(IDC_Picture);
		pPicture->ShowWindow(SW_HIDE);

		BmpMem.Attach((HBITMAP)LoadImage(AfxGetInstanceHandle(),
			MAKEINTRESOURCE(IDB_BITMAP_BIG),
			IMAGE_BITMAP,
			0, 0,
			LR_CREATEDIBSECTION));
	}
	
		
	MemDC.SelectObject(&BmpMem);
	
	pDC->BitBlt(15,15,673,551,&MemDC,m_mapLocation.x,m_mapLocation.y,SRCCOPY);

}
void CGuidanceDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
    if (point.x>15 && point.x<(15+551) && point.y>15 && point.y<(15+673))
		m_lButtonDown=true;
	else
		m_lButtonDown=false;

	m_orginalPoint=point;
	m_mapTempLocation=m_mapLocation;
	CDialog::OnLButtonDown(nFlags, point);
}
void CGuidanceDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	m_lButtonDown=false;
	m_destinationPoint=point;
	m_mapLocation.x=m_mapTempLocation.x-(m_destinationPoint.x-m_orginalPoint.x);
	m_mapLocation.y=m_mapTempLocation.y-(m_destinationPoint.y-m_orginalPoint.y);	
	CDialog::OnLButtonUp(nFlags, point);
}
void CGuidanceDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if (point.x<15 || point.x>(15+551) || point.y<15 || point.y>(15+673))
		m_lButtonDown=false;

	int changesToPointX=0;
	int changesToPointY=0;

	CDC *pDC=GetDC();
	CBitmap BmpMem;
	CDC MemDC;

	MemDC.CreateCompatibleDC(pDC);

	if(m_size==1 && m_lButtonDown==true && m_mapLocation.x>0 && m_mapLocation.y>0
		&& m_mapLocation.x<(1682-673) && m_mapLocation.y <(1377-551)){
	
		if (m_size == 0)
		{
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP_SMALL);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			pPic->ShowWindow(SW_SHOW);
		}
		else 
		{
			CStatic* pPicture = (CStatic*)GetDlgItem(IDC_Picture);
			pPicture->ShowWindow(SW_HIDE);

			BmpMem.Attach((HBITMAP)LoadImage(AfxGetInstanceHandle(),
				MAKEINTRESOURCE(IDB_BITMAP_BIG),
				IMAGE_BITMAP,
				0, 0,
				LR_CREATEDIBSECTION));
		}

		changesToPointX=point.x-m_currentPoint.x;
		changesToPointY=point.y-m_currentPoint.y;
		m_mapLocation.x-=changesToPointX;
		m_mapLocation.y-=changesToPointY;
			
		MemDC.SelectObject(&BmpMem);
	
		pDC->BitBlt(15,15,673,551,&MemDC,	m_mapLocation.x,
			m_mapLocation.y,SRCCOPY);

		BmpMem.DeleteObject();
		MemDC.DeleteDC();
	//	pDC->DeleteDC();
	ReleaseDC(pDC);	//	ReleaseDC(MemDC);	
	}

	m_currentPoint=point;
		
	CDialog::OnMouseMove(nFlags, point);
}
/////////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////

//Part3�����㷨����
#define MAXV 65
#define M 32767 
typedef int InfoType; 
//�ڽӾ���
typedef struct { 
	int no; 
	InfoType info; 
	}
 VertexType; 
typedef struct {
	float edges[MAXV][MAXV]; 
	int a,b,n; 
	VertexType vexs[MAXV]; 
}MGraph;
int way[MAXV];
int pathpoint[MAXV]; 
int m=1;
int index[100],check = 0;
//У԰������
CString  name[100]={"��԰������","�����¥","����¥","��ұ�¥","������","��ѧ¥��","����¥","�Ŀ�¥","��������","Բ����","��е¥", "ͼ���",
"ͼ��ݶ�","Բ����","��ѧ�����ѧԺ","������","ͼ��ݱ�","����","��԰ʳ��","УҽԺ","��ѧ����¥","��԰�ٳ�","��԰������","��԰����","÷԰����",
"÷԰������","÷԰������","����","����������","Բ������","Բ������","����","����","����","Բ������","����ʵ��¥"};
//У԰��ͼ����
float seu[MAXV][MAXV]={
0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,114.655,35.7976,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,0,55.3627,M,M,M,M,M,M,M,M,M,M,27.2324,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,58.6941,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,64.6297,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,55.3627,0,M,M,M,M,M,M,M,M,M,M,38.2477,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,61.4163,M,M,M,M,M,M,M,M,M,M,M,M,M,M,62.2192,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,31.2868,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,61.9427,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,57.7753,M,116.996,M,M,M,M,M,M,M,M,M,M,57.8803,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,0,M,M,M,M,M,M,78.0784,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,42.5926,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,88.0807,M,126.766,M,M,M,M,M,M,M,M,M,M,M,M,M,M,78.7652,M,M,57.1355,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,28.3182,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,65.1338,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,67.5979,M,M,M,M,M,M,M,26.5726,M,M,M,
M,M,M,M,M,M,M,M,0,M,35.5428,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,51.8362,M,M,M,M,M,M,M,M,M,M,M,M,M,40.724,M,
M,M,M,M,M,M,M,M,M,0,31.4514,102.297,190.906,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,77.9687,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,87.3064,M,M,M,M,M,M,M,M,M,M,M,M,47.2754,M,M,
M,M,M,M,M,M,M,M,35.5428,31.4514,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,61.1882,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,102.297,M,0,99.026,M,26.6641,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,78.0784,M,M,M,190.906,M,99.026,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,71.289,M,M,M,69.3149,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,102.036,M,M,M,M,M,M,M,M,M,M,
M,27.2324,38.2477,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,65.7978,81.3439,M,M,M,M,M,M,M,M,M,M,M,M,M,M,82.3279,83.3305,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,26.6641,M,M,0,M,38.4393,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,68.0812,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,65.1338,M,M,M,M,M,M,M,0,68.7647,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,29.5484,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,38.4393,68.7647,0,M,M,M,32.8875,M,M,M,M,M,M,M,M,M,M,M,M,M,76.574,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,43.7592,M,M,M,M,
M,M,M,M,61.9427,M,M,M,M,M,M,M,M,M,M,M,M,0,40.4773,M,M,M,80.9178,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,69.2606,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,88.0807,M,M,M,M,M,M,M,M,M,M,40.4773,0,M,M,M,62.4747,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,70.8862,M,M,M,M,M,M,M,M,M,M,35.8581,121.03,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,126.766,M,M,M,M,M,M,M,M,M,32.8875,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,63.6947,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,62.7984,M,48.1111,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,37.1214,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,44.4201,121.08,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,80.9178,62.4747,M,M,37.1214,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,70.3562,M,M,M,M,M,M,M,M,M,M,M,M,M,M,52.0955,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,47.0915,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,30.4631,M,M,M,M,M,M,M,M,M,M,M,M,82.0846,M,M,M,M,M,M,M,46.537,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,94.0198,25.3158,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,47.0915,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,26.4229,M,M,M,M,M,M,M,M,M,M,M,M,84.9859,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,70.8862,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,70.287,76.6915,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,103.127,M,M,M,M,M,M,M,M,M,M,M,M,M,M,166.883,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,58.6941,M,M,M,M,M,M,M,77.9687,M,M,M,65.7978,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,61.4163,M,M,M,M,M,M,M,M,M,71.289,81.3439,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,64.6584,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,50.4571,47.4514,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,31.949,M,M,82.1231,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,69.3149,M,68.0812,M,76.574,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,78.7652,M,M,M,M,M,M,M,M,M,M,M,M,M,63.6947,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,108.696,96.169,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,33.1386,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,103.127,M,M,M,M,M,M,M,0,214.037,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,70.287,M,M,M,M,M,M,M,108.696,214.037,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,90.4214,M,M,M,M,M,M,M,
M,M,M,M,M,M,57.1355,M,M,M,M,M,M,M,M,M,M,M,M,35.8581,M,M,M,M,M,M,M,76.6915,M,M,M,M,M,M,M,96.169,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,45.0239,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,121.03,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,51.0393,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,44.4201,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,51.0393,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,135.844,M,M,M,M,M,M,M,M,M,
M,M,M,M,57.7753,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,121.08,M,M,M,94.0198,M,M,M,M,M,64.6584,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,25.3158,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,53.0094,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,116.996,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,30.4631,M,26.4229,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,53.0094,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,31.2868,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,104.389,M,M,M,M,M,M,M,M,M,M,48.6212,M,M,M,M,M,M,M,M,
M,M,62.2192,M,M,M,M,M,M,M,M,M,M,82.3279,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,50.4571,M,M,M,M,M,M,M,M,M,M,M,104.389,0,41.4367,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
114.655,64.6297,M,M,M,M,M,M,M,M,M,M,M,83.3305,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,47.4514,M,M,M,M,M,M,M,M,M,M,M,M,41.4367,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,
35.7976,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,118.303,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,70.3562,M,M,M,M,M,M,M,M,M,31.949,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,65.5615,M,88.1576,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,51.8362,87.3064,61.1882,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,65.5615,0,83.0241,M,M,M,M,M,M,M,M,M,M,M,M,51.0882,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,83.0241,0,84.0236,91.1976,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,166.883,M,M,M,M,82.1231,M,M,M,M,M,M,M,M,M,M,M,M,M,M,88.1576,M,84.0236,0,M,M,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,91.1976,M,0,41.4367,M,M,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,67.5979,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,41.4367,0,M,M,M,M,M,112.004,M,M,M,M,M,
M,M,M,M,57.8803,42.5926,M,M,M,M,M,M,102.036,M,M,M,M,69.2606,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,149.282,M,M,M,M,M,M,M,M,84.0536,
M,M,M,M,M,M,28.3182,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,45.0239,M,135.844,M,M,M,M,M,M,M,M,M,M,M,M,M,149.282,0,M,M,M,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,82.0846,M,84.9859,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,48.6212,M,M,M,M,M,M,M,M,M,M,M,0,M,M,M,M,M,M,M,80.895,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,33.1386,M,90.4214,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,41.0488,M,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,62.7984,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,41.0488,0,29.4279,M,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,112.004,M,M,M,M,29.4279,0,37.054,M,M,M,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,43.7592,M,M,M,48.1111,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,37.054,0,55.0091,M,M,M,
M,M,M,M,M,M,M,26.5726,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,55.0091,0,M,M,M,
M,M,M,M,M,M,M,M,M,47.2754,M,M,M,M,M,29.5484,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,M,
M,M,M,M,M,M,M,M,40.724,M,M,M,M,M,M,M,M,M,M,M,M,M,M,52.0955,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,118.303,M,51.0882,M,M,M,M,M,M,M,M,M,M,M,M,M,0,M,
M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,46.537,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,84.0536,M,80.895,M,M,M,M,M,M,M,0

};
//���������㷨 
void Ppath1(int path[][MAXV],int a,int b) {
	int k; 
	k=path[a][b]; 
	if(k==-1) return; 
	Ppath1(path,a,k); 
	way[m++]=k; 
	Ppath1(path,k,b); 
} 
void Dispath1(float A[][MAXV],int path[][MAXV],int a,int b) {
	int dis;
	dis=A[a][b]; 
	way[0]=a; 
	Ppath1(path,a,b); 
	way[m++]=b; 
	for (int i=m;i<MAXV;i++){
	way[i]=999;
	}
} 
float AA[MAXV][MAXV];
void Floyd(MGraph g,bool flag) {
	INT path[MAXV][MAXV]; 
	int i,j,k; 
	for(i=0;i<65;i++) {
		for(j=0;j<65;j++) {
			AA[i][j]=g.edges[i][j]; 
			path[i][j]=-1; 
		}
	} 
	for(k=0;k<65;k++) {
		for(i=0;i<65;i++) {
			for(j=0;j<65;j++) {
				if(AA[i][j]>AA[i][k]+AA[k][j]) {
					AA[i][j]=AA[i][k]+AA[k][j]; 
					path[i][j]=k; 
				} 
			}
		}
	} 
if(flag)Dispath1(AA,path,g.a,g.b); 
} 
void trace(MGraph line) 
{
	int k=line.n;
	pathpoint[0]=k;

	Floyd(line,0);
	int i,j,point,num=check;
	double min;
	for(i=1;i<=num;i++)
	{min=32767;
	point=32767;
	for(j=0;j<check;j++)
	{
		if((index[j]!=-1)&&(AA[pathpoint[i-1]][index[j]]<min))
		{min=AA[pathpoint[i-1]][index[j]];point=j;}
	}
	
	pathpoint[i]=index[point];
	index[point]=-1;
	}
	
}

/////////////////////////////Floyd////////////////////////////////////////
void CGuidanceDlg::OnLead() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
    //m_leadClicked=true;	
	//BmpMem.Attach((HBITMAP)::LoadImage(NULL,"small.bmp",IMAGE_BITMAP,0,0,LR_LOADFROMFILE));
	int i,j; 
	CString out;
	Invalidate();
	UpdateWindow();
	m=1;
	MGraph g;
	for (i=0;i<65;i++){
		for (j=0;j<65;j++){
			g.edges[i][j]=seu[i][j];
		}
	}
	int m=m_original.GetCurSel();
	int n=m_destination.GetCurSel();
	g.a=m;
	g.b=n;
	
	Floyd(g,1);
    
	i=0;j=1;
	float xx[65]={177.05-22,282.703-22,337.921-22,428.674-22,557.945-22,469.985-22,448.601-22,204.487-22,155.607-22,207.321-22,180.095-22,303.074-22,398.059-22,302.577-22,301.087-22,239.002-22,298.285-22,535.42-22,529.399-22,489.727-22,323.584-22,625.095-22,588.095-22,70.0502-22,539.703-22,622.674-22,566.945-22,440.985-22,59.0952-22,240.703-22,377.05-22,680.05-22,315.095-22,23.0502-22,368.674-22,372.399-22,156.703-22,370.703-22,461.703-22,610.703-22,608.703-22,615.703-22,620.703-22,567.703-22,436.703-22,332.703-22,291.703-22,141.703-22,54.7033-22,120.095-22,118.095-22,34.0952-22,124.095-22,165.095-22,500.095-22,474.095-22,485.095-22,347.095-22,306.095-22,277.095-22,279.095-22,224.095-22,217.095-22,117.095-22,497.095};
	float yy[65]={479.876-22,415.214-22,411.214-22,433.975-22,293.626-22,265.374-22,160.827-22,182.433-22,345.26-22,303.753-22,319.499-22,267.753-22,295.753-22,396.596-22,241.163-22,237.67-22,202.826-22,235.924-22,195.897-22,82.8431-22,181.813-22,171.499-22,174.499-22,380.876-22,398.214-22,385.975-22,436.626-22,31.374-22,61.4992-22,374.214-22,363.876-22,285.876-22,520.499-22,307.876-22,232.975-22,140.897-22,28.2139-22,32.2139-22,105.214-22,79.2139-22,130.214-22,292.214-22,411.214-22,410.214-22,464.214-22,473.214-22,479.214-22,474.214-22,312.214-22,307.499-22,224.499-22,226.499-22,133.499-22,127.499-22,295.499-22,148.499-22,459.499-22,119.499-22,121.499-22,126.499-22,163.499-22,164.499-22,257.499-22,358.499-22,379.499};
	CClientDC dc(this);
	CPen penNew;
	penNew.CreatePen(PS_SOLID, 4, RGB(220,20,60));
	CPen* Old = dc.SelectObject(&penNew);
	CString ss;
	ss.Format("%d",(int)(AA[g.a][g.b]*2.631));
	out=out+name[g.a]+"->"+name[g.b]+":"+ss+"��\n";
	while(way[i]!=999&&way[j]!=999)
	{
		m=way[i];
		n=way[j];
		dc.MoveTo(xx[m],yy[m]);
		dc.LineTo(xx[n],yy[n]);
		i++;
		j++;
	}
	
	MessageBox(out);
	UpdateData(FALSE);
}
void CGuidanceDlg::OnCloseupOriginal() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CComboBox *cbx=(CComboBox*)GetDlgItem(IDC_ORIGINAL);
	m_comboBoxOriginalIndex=cbx->GetCurSel();
	
}
void CGuidanceDlg::OnCloseupDestination() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);	
}
void CGuidanceDlg::OnCloseupDestination2() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);	
}
void CGuidanceDlg::OnSelchangeDestination3() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
}
void CGuidanceDlg::OnDecision() 
{
	// TODO: Add your control notification handler code here
		UpdateData(TRUE);
	Invalidate();
	UpdateWindow();
	int i,j,c; 
	MGraph line; 

    int  itemCount = m_destination3.GetCount();
	check = m_destination3.GetSelItems(itemCount, index);

	for (i=0;i<65;i++)
	{
		for (j=0;j<65;j++)
		{
			line.edges[i][j]=seu[i][j];
		}
	}
	c=m_destination2.GetCurSel();
	line.n=c;
	
		
	trace(line);
    
	float xx[65] = { 177.05 - 22,282.703 - 22,337.921 - 22,428.674 - 22,557.945 - 22,469.985 - 22,448.601 - 22,204.487 - 22,155.607 - 22,207.321 - 22,180.095 - 22,303.074 - 22,398.059 - 22,302.577 - 22,301.087 - 22,239.002 - 22,298.285 - 22,535.42 - 22,529.399 - 22,489.727 - 22,323.584 - 22,625.095 - 22,588.095 - 22,70.0502 - 22,539.703 - 22,622.674 - 22,566.945 - 22,440.985 - 22,59.0952 - 22,240.703 - 22,377.05 - 22,680.05 - 22,315.095 - 22,23.0502 - 22,368.674 - 22,372.399 - 22,156.703 - 22,370.703 - 22,461.703 - 22,610.703 - 22,608.703 - 22,615.703 - 22,620.703 - 22,567.703 - 22,436.703 - 22,332.703 - 22,291.703 - 22,141.703 - 22,54.7033 - 22,120.095 - 22,118.095 - 22,34.0952 - 22,124.095 - 22,165.095 - 22,500.095 - 22,474.095 - 22,485.095 - 22,347.095 - 22,306.095 - 22,277.095 - 22,279.095 - 22,224.095 - 22,217.095 - 22,117.095 - 22,497.095 };
	float yy[65] = { 479.876 - 22,415.214 - 22,411.214 - 22,433.975 - 22,293.626 - 22,265.374 - 22,160.827 - 22,182.433 - 22,345.26 - 22,303.753 - 22,319.499 - 22,267.753 - 22,295.753 - 22,396.596 - 22,241.163 - 22,237.67 - 22,202.826 - 22,235.924 - 22,195.897 - 22,82.8431 - 22,181.813 - 22,171.499 - 22,174.499 - 22,380.876 - 22,398.214 - 22,385.975 - 22,436.626 - 22,31.374 - 22,61.4992 - 22,374.214 - 22,363.876 - 22,285.876 - 22,520.499 - 22,307.876 - 22,232.975 - 22,140.897 - 22,28.2139 - 22,32.2139 - 22,105.214 - 22,79.2139 - 22,130.214 - 22,292.214 - 22,411.214 - 22,410.214 - 22,464.214 - 22,473.214 - 22,479.214 - 22,474.214 - 22,312.214 - 22,307.499 - 22,224.499 - 22,226.499 - 22,133.499 - 22,127.499 - 22,295.499 - 22,148.499 - 22,459.499 - 22,119.499 - 22,121.499 - 22,126.499 - 22,163.499 - 22,164.499 - 22,257.499 - 22,358.499 - 22,379.499 };

    CString out;
	for(i=0;i<check;i++)
	{	

		m=1;
		int x,y;
		MGraph g;
		for (x=0;x<65;x++)
			for(y=0;y<65;y++)
				g.edges[x][y]=seu[x][y];
		CString ss;
		ss.Format("%d",(int)(AA[pathpoint[i]][pathpoint[i+1]]*2.631));
	    out=out+name[pathpoint[i]]+"->"+name[pathpoint[i+1]]+":"+ss+"��\n";
		int m,n;	
		g.a=pathpoint[i];
		g.b=pathpoint[i+1];
	
		Floyd(g,1);
    
		CClientDC dc(this);
		CPen penNew;
		penNew.CreatePen(PS_SOLID, 4, RGB(255,70*i%256,30*i%256));
		CPen* Old = dc.SelectObject(&penNew);
		x=0;y=1;
		while(way[x]!=999 && way[y]!=999)
		{
			m=way[x];
			n=way[y];
			dc.MoveTo(xx[m],yy[m]);
			dc.LineTo(xx[n],yy[n]);
			x++;
			y++;
			}
		}
	
	MessageBox(out);
	UpdateData(FALSE);
}
bool m_bFullSceen=false;
void CGuidanceDlg::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
		if(m_bFullSceen)
	{
		m_bFullSceen=false;  
		 ShowWindow(SW_SHOWNORMAL);  
		
	}
	else
	{
		m_bFullSceen=true;
		ShowWindow(SW_SHOWMAXIMIZED);	
	}
	CDialog::OnLButtonDblClk(nFlags, point);
}
void CGuidanceDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	if(nType==SIZE_RESTORED||nType==SIZE_MAXIMIZED)//�����С�����䶯����������resize
	{
		 //SetWindowPos(&wndTopMost, 0, 0, GetSystemMetrics(SM_CXSCREEN) - 1, GetSystemMetrics(SM_CYSCREEN), 0); 
		resize();
	}
	// TODO: Add your message handler code here
	
}
void CGuidanceDlg::OnCbnSelchangeOriginal()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}
void CGuidanceDlg::OnStnClickedmudidi2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}
void CGuidanceDlg::OnStnClickedxiansuozaididian()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}