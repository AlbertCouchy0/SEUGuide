#if !defined(AFX_GUIDANCEDLG_H__D431FA1B_0B80_45EA_A8EC_9785DA6B9A0E__INCLUDED_)
#define AFX_GUIDANCEDLG_H__D431FA1B_0B80_45EA_A8EC_9785DA6B9A0E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GuidanceDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGuidanceDlg dialog

class CGuidanceDlg : public CDialog
{
// Construction
public:
	CGuidanceDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGuidanceDlg)
	enum { IDD = IDD_Guidance };
	CComboBox	m_destination2;
	CListBox	m_destination3;
	CComboBox	m_original;
	CComboBox	m_destination;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGuidanceDlg)
	public:
	virtual int DoModal();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGuidanceDlg)
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
	afx_msg void OnSmall();
	afx_msg void OnBig();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLead();
	afx_msg void OnCloseupOriginal();
	afx_msg void OnCloseupDestination();
	afx_msg void OnCloseupDestination2();
	afx_msg void OnSelchangeDestination3();
	afx_msg void OnDecision();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP();
private:
	int m_comboBoxDestinationIndex;
	BOOL m_colorOfFlash;
	int m_comboBoxOriginalIndex;
	CPoint m_startPoint;
	CPoint m_touristAttractions[100];
	BOOL m_leadClicked;
	CPoint m_mapTempLocation;
	CPoint m_currentPoint;
	CPoint m_destinationPoint;
	CPoint m_mapLocation;
	CPoint m_orginalPoint;
	BOOL m_lButtonDown;
	BOOL m_size;
	void resize();
public:
	afx_msg void OnCbnSelchangeOriginal();
	afx_msg void OnStnClickedmudidi2();
	afx_msg void OnStnClickedxiansuozaididian();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GUIDANCEDLG_H__D431FA1B_0B80_45EA_A8EC_9785DA6B9A0E__INCLUDED_)
