// IntroductionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Whole.h"
#include "IntroductionDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// IntroductionDlg dialog


IntroductionDlg::IntroductionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(IntroductionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(IntroductionDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void IntroductionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(IntroductionDlg)
	DDX_Control(pDX, IDC_Picture, picture);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(IntroductionDlg, CDialog)
	//{{AFX_MSG_MAP(IntroductionDlg)
	ON_WM_PAINT()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// IntroductionDlg message handlers

void IntroductionDlg::OnPaint() //������ͼƬ
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	CDC* pDC = GetDC();
	CBitmap BmpMem;
	CDC MemDC;
	MemDC.CreateCompatibleDC(pDC);
	//BmpMem.Attach((HBITMAP)::LoadImage(NULL, TEXT("intro.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE));
	MemDC.SelectObject(&BmpMem);
	CRect rect;
	GetWindowRect(&rect);

	pDC->BitBlt(0, 0, rect.Width(), rect.Height(), &MemDC, 0, 0, SRCCOPY);

	
}

void IntroductionDlg::OnMouseMove(UINT nFlags, CPoint point) 
{	// TODO: Add your message handler code here and/or call default
	int x = point.x;
	int y = point.y;
	CString str;
	str.Format(_T("%d,%d"), x, y);
	CDC* pDC = GetDC();
	pDC->TextOut(0, 0, str);
	ReleaseDC(pDC);
	if (point.x > 300 && point.x < 340 && point.y>380 && point.y <420 ) {
	    picture.SetWindowPos(NULL, point.x + 1, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
		CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
		CBitmap bitmap;
		bitmap.LoadBitmap(IDB_BITMAP1);
		pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());//computer software
		HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
		::SetCursor(hCur);
	}
	if (point.x > 440 && point.x < 470 && point.y>470 && point.y <510 ) {//Phycics
	    picture.SetWindowPos(NULL, point.x + 1, point.y - 275, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
		CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
		CBitmap bitmap;
		bitmap.LoadBitmap(IDB_BITMAP2);
		pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
		HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
		::SetCursor(hCur);

	}
	if (point.x > 660 && point.x < 750 && point.y>480 && point.y <530 ) {//gangju
	    picture.SetWindowPos(NULL, point.x - 500, point.y - 275, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
		CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
		CBitmap bitmap;
		bitmap.LoadBitmap(IDB_BITMAP3);
		pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
		HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
		::SetCursor(hCur);

	}
	if (point.x > 600 && point.x < 692 && point.y>347 && point.y <400 ) {//learning
	    picture.SetWindowPos(NULL, point.x + 1, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
		CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
		CBitmap bitmap;
		bitmap.LoadBitmap(IDB_BITMAP4);
		pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
		HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
		::SetCursor(hCur);

	}
	if (point.x > 307 && point.x < 336 && point.y>274 && point.y <309 ) {//machine
	    picture.SetWindowPos(NULL, point.x + 1, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
		CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
		CBitmap bitmap;
		bitmap.LoadBitmap(IDB_BITMAP5);
		pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
		HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
		::SetCursor(hCur);
	
	}
	if (point.x > 460 && point.x < 500 && point.y>200 && point.y <250 ) {//renwen
	    picture.SetWindowPos(NULL, point.x + 1, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
		CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
		CBitmap bitmap;
		bitmap.LoadBitmap(IDB_BITMAP6);
		pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
		HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
		::SetCursor(hCur);

	}
	if (point.x > 264 && point.x < 288 && point.y>251 && point.y <282 ) {//gongpei
	    picture.SetWindowPos(NULL, point.x + 1, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
		CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
		CBitmap bitmap;
		bitmap.LoadBitmap(IDB_BITMAP7);
		pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
		HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
		::SetCursor(hCur);

	}
	if (point.x > 440 && point.x < 550 && point.y>276 && point.y <340 ) {//tushuguan
			picture.SetWindowPos(NULL, point.x + 1, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP8);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);

	}
	if (point.x > 210 && point.x < 330 && point.y>410 && point.y <470 ) {//xingzheng
			picture.SetWindowPos(NULL, point.x + 1, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP9);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);

	}
	if (point.x > 74 && point.x < 123 && point.y>329 && point.y <372 ) {//juyuan shenghuo
			picture.SetWindowPos(NULL, point.x + 1, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP10);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);

	}
	if (point.x > 738 && point.x < 759 && point.y>434 && point.y <454 ) {//jiaobiao
			picture.SetWindowPos(NULL, point.x - 500, point.y - 275, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP11);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);

	}
	if (point.x > 751 && point.x < 774 && point.y>393 && point.y <426 ) {//tao shitang
			picture.SetWindowPos(NULL, point.x -500, point.y -275, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP12);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);

	}
	if (point.x > 844 && point.x < 867 && point.y>290 && point.y <316 ) {//yiyuan
			picture.SetWindowPos(NULL, point.x -500, point.y -275, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP13);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);

	}
	if (point.x > 580 && point.x < 640 && point.y>250 && point.y <300 ) {//huaxue
			picture.SetWindowPos(NULL, point.x + 1, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP14);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}	
	if (point.x > 834 && point.x < 949 && point.y>384 && point.y <476 ) {//taoyuan shenghuo
			picture.SetWindowPos(NULL, point.x -500, point.y -275, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP15);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	if (point.x > 574 && point.x < 598 && point.y>537 && point.y <559 ) {//meiyuan shitang
			picture.SetWindowPos(NULL, point.x -500, point.y - 275, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP16);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	if (point.x > 512 && point.x < 676 && point.y>567 && point.y <662 ) {//meiyuan shenghuo
			picture.SetWindowPos(NULL, point.x -500, point.y -275, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP17);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	if (point.x > 415 && point.x < 466 && point.y>34 && point.y <60 ) {//bingguan
			picture.SetWindowPos(NULL, point.x + 1, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP18);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	if (point.x > 656 && point.x < 681 && point.y>273 && point.y <291 ) {//tujiao shiyan
			picture.SetWindowPos(NULL, point.x - 500, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP19);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	if (point.x > 195 && point.x < 210 && point.y>193 && point.y <220 ) {//����
			picture.SetWindowPos(NULL, point.x + 1, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP20);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	if (point.x > 740 && point.x < 771 && point.y>200 && point.y <241 ) {//����
			picture.SetWindowPos(NULL, point.x -500, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP21);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	if (point.x > 810 && point.x < 832 && point.y>540 && point.y <580 ) {//����
			picture.SetWindowPos(NULL, point.x - 500, point.y - 275, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP22);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	if (point.x > 254 && point.x < 276 && point.y>476 && point.y <510 ) {//����
			picture.SetWindowPos(NULL, point.x +1, point.y - 275, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP23);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	if (point.x > 234 && point.x < 250 && point.y>300 && point.y <340 ) {//��е����
			picture.SetWindowPos(NULL, point.x + 1, point.y + 1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP24);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	if (point.x > 370 && point.x < 425 && point.y>415 && point.y <460 ) {//����¥
			picture.SetWindowPos(NULL, point.x+1 , point.y+1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP25);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	if (point.x > 320 && point.x < 382 && point.y>223 && point.y <289 ) {//����¥
			picture.SetWindowPos(NULL, point.x+1 , point.y+1, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP26);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	if (point.x > 726 && point.x < 759 && point.y>300 && point.y <341 ) {//����ľ��ͨ
			picture.SetWindowPos(NULL,  point.x - 500, point.y - 275, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			CStatic* pPic = (CStatic*)GetDlgItem(IDC_Picture);
			CBitmap bitmap;
			bitmap.LoadBitmap(IDB_BITMAP27);
			pPic->SetBitmap((HBITMAP)bitmap.GetSafeHandle());
			HCURSOR hCur = LoadCursor( NULL , IDC_HAND ) ;
			::SetCursor(hCur);
	}
	CDialog::OnMouseMove(nFlags, point);
}

