// Whole.h : main header file for the WHOLE application
//

#if !defined(AFX_WHOLE_H__4F774A10_CEAB_4681_8172_B67FF43E7B74__INCLUDED_)
#define AFX_WHOLE_H__4F774A10_CEAB_4681_8172_B67FF43E7B74__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
 
/////////////////////////////////////////////////////////////////////////////
// CWholeApp:
// See Whole.cpp for the implementation of this class
//

class CWholeApp : public CWinApp
{
public:
	CWholeApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWholeApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CWholeApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WHOLE_H__4F774A10_CEAB_4681_8172_B67FF43E7B74__INCLUDED_)
